document.addEventListener("DOMContentLoaded", function() {
    const openCartButton = document.getElementById("open-cart");
    const closeCartButton = document.getElementById("close-cart");
    const cartOverlay = document.getElementById("cart-overlay");

    openCartButton.addEventListener("click", function() {
        cartOverlay.style.display = "flex";
    });

    closeCartButton.addEventListener("click", function() {
        cartOverlay.style.display = "none";
    });

    // Restante do código para gerenciar o carrinho (adicionar, remover itens, calcular total) permanece o mesmo
});